"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowService_1 = require("../../service/FollowService");
const tweeter_shared_1 = require("tweeter-shared");
const handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const service = new FollowService_1.FollowService();
        const count = await service.getFolloweeCount(tweeter_shared_1.AuthToken.fromDto(body.authToken), tweeter_shared_1.User.fromDto(body.user));
        return {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: true, count }),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: false, message: error.message }),
        };
    }
};
exports.handler = handler;
