"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const FollowService_1 = require("../../service/FollowService");
const tweeter_shared_1 = require("tweeter-shared");
const handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const service = new FollowService_1.FollowService();
        const [users, hasMore] = await service.loadMoreFollowees(tweeter_shared_1.AuthToken.fromDto(body.authToken), body.userAlias, body.pageSize, body.lastItem ? tweeter_shared_1.User.fromDto(body.lastItem) : null);
        return {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: true, items: users.map((u) => u.dto), hasMore }),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: false, message: error.message }),
        };
    }
};
exports.handler = handler;
