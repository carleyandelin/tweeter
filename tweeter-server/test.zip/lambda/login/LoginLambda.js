"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const UserService_1 = require("../../service/UserService");
const handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const service = new UserService_1.UserService();
        const [user, authToken] = await service.login(body.alias, body.password);
        return {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: true, user: user.dto, authToken: authToken.dto }),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: false, message: error.message }),
        };
    }
};
exports.handler = handler;
