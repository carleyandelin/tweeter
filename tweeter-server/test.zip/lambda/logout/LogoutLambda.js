"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const UserService_1 = require("../../service/UserService");
const tweeter_shared_1 = require("tweeter-shared");
const handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const service = new UserService_1.UserService();
        await service.logout(tweeter_shared_1.AuthToken.fromDto(body.authToken));
        return {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: true }),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: false, message: error.message }),
        };
    }
};
exports.handler = handler;
