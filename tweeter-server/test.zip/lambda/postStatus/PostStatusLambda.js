"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const StatusService_1 = require("../../service/StatusService");
const tweeter_shared_1 = require("tweeter-shared");
const handler = async (event) => {
    try {
        const body = JSON.parse(event.body);
        const service = new StatusService_1.StatusService();
        await service.postStatus(tweeter_shared_1.AuthToken.fromDto(body.authToken), tweeter_shared_1.Status.fromDto(body.newStatus));
        return {
            statusCode: 200,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: true }),
        };
    }
    catch (error) {
        return {
            statusCode: 500,
            headers: { "Access-Control-Allow-Origin": "*" },
            body: JSON.stringify({ success: false, message: error.message }),
        };
    }
};
exports.handler = handler;
